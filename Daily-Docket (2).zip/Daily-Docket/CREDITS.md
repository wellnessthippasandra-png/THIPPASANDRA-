# Credits

Daily Docket builds on the user-provided Daily Docket HTML project.

Bundled typefaces:

- IBM Plex Sans and IBM Plex Mono — IBM Corp.; SIL Open Font License 1.1. License files are included in `assets/fonts/`.
- Special Elite — Brian J. Bonislawsky, Astigmatic; Apache License 2.0. The license is included in `assets/fonts/`.

All application icons were created for this project. No external images or runtime libraries are used.
