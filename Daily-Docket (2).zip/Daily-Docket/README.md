# Daily Docket

A downloadable, offline-ready task log with follow-ups, read-aloud, voice input, a daily store visit checklist, local backups, printing, and optional Google Sheets sync.

## Open the app

- **Quick start:** extract the ZIP and double-click `index.html`. Tasks, follow-ups, editing, checklists, and JSON backups work from the local file.
- **Install/offline app:** serve this folder over HTTP or HTTPS, open it in a modern browser, and use the browser's install option. The service worker caches the app shell and bundled fonts for offline use.
- For a local server, run `python3 -m http.server 8080` in this folder and open `http://localhost:8080`.

## Data and backups

Tasks and checklist progress are stored in the current browser's local storage. They do not automatically move between browsers or devices. Clearing site/browser data can erase them. Use **Data, backup & sheet connection → Export backup** regularly, and **Import backup** to restore on another browser.

The daily checklist resets on the device's local calendar day. Completing a task records its completion time for the “Done Today” statistic.

## Google Sheets

The Apps Script web-app URL is set as `SHEET_URL` near the top of `app.js`. Updates are sent once per action. Because the browser uses a no-CORS request, the app can report that a request was sent but cannot verify that the sheet accepted or wrote it. Check the sheet for confirmation.

**Test sheet connection** sends clearly marked test rows to both the `Tasks` and `FollowUps` tabs. It does not read or validate the sheet. Sheet sync is one-way: importing a backup or opening the app does not download sheet rows.

## Files

- `index.html` — semantic page and forms
- `styles.css` — responsive layout, print styles, and local font declarations
- `app.js` — tasks, checklist, backups, voice, and sheet requests
- `manifest.webmanifest`, `sw.js`, `icon-*.png` — installable/offline app files
- `assets/fonts/` — bundled fonts and their licenses

No build step or external runtime dependency is required.
