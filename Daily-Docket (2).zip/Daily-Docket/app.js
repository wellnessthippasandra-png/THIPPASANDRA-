(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const TASKS_KEY = 'dd_tasks';
  const CHECKLIST_KEY = 'dd_checklist';
  const SHEET_URL = 'https://script.google.com/macros/s/AKfycbzq02r-wqinNqfEc3Tk9MBmyBS6JGBrBETPmPgBv6-_hP5c0XGDzaO5ZVbKTZ4DVjHbdg/exec';
  const PRIORITIES = ['high', 'medium', 'low'];

  const CHECKLIST_DATA = [
    { cat: 'Meeting', color: 'var(--stamp-blue)', items: [
      'Sales', 'Sales return', 'GDN / GRN pending', 'T-COM', 'Invoice creation',
      'NRTV expiry', 'CX outstanding', 'MEQ / lamp', 'Pine Lab / reverse scanning',
      'Shrinkage', 'Shift closing', 'CCRA', 'Audit on audit'
    ]},
    { cat: 'Book', color: 'var(--stamp-purple)', items: [
      'Amore / BBB', 'Manual bill book', 'GDN / GRN book, shift book', 'TAT book',
      'Expiry, NRTV, RTV, near expiry'
    ]},
    { cat: 'Online', color: 'var(--stamp-pink)', items: [
      'WhatsApp chat box', 'WhatsApp order / T-COM order', 'CX calling', 'Delay order',
      'Online order / on-time delivery', 'Pine Lab 95% and above', 'Category sale dashboard'
    ]},
    { cat: 'Ecogreen', color: 'var(--stamp-green)', items: [
      'Cycle / random audit', 'Return random', 'Shift closing 3 times', 'Phone pay / card settlement',
      'General customer', 'Cash receipt', 'ZEDC stock receiving', 'Top 1000 SQS, NAQ report',
      'Reverse scanning 95% above', 'Zero stock report', 'Non moving', 'Discount',
      'Local purchase inward check'
    ]},
    { cat: 'Process', color: 'var(--stamp-mustard)', items: [
      'Camera checking', 'Universal location', 'Planogram', 'Rag rag photo', 'Individual target',
      'Night team task', '3 PM set up and 6 AM set up', 'Staff KPI / KRA, attendance',
      'Lamp on daily basis', 'Staff on market', 'Offer communication', 'Staff room checking',
      'Prescription upload'
    ]}
  ];

  let tasks = [];
  let checklistState = { date: '', checked: {} };
  let editingId = null;
  let currentDay = '';
  let toastTimer = null;
  let syncTimer = null;

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[char]);
  }

  function makeId() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    return `t${Date.now()}${Math.random().toString(36).slice(2, 9)}`;
  }

  function todayStr(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function isValidDateString(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [year, month, day] = value.split('-').map(Number);
    const date = new Date(year, month - 1, day);
    return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
  }

  function isValidTimeString(value) {
    return typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
  }

  function safeText(value, maxLength = 2000) {
    return String(value ?? '').trim().slice(0, maxLength);
  }

  function normalizeTask(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const title = safeText(raw.title, 240);
    if (!title) return null;
    const status = raw.status === 'done' ? 'done' : 'pending';
    const followUps = Array.isArray(raw.followUps) ? raw.followUps.slice(0, 500).map((entry) => {
      if (!entry || typeof entry !== 'object') return null;
      const note = safeText(entry.note, 1000);
      if (!note) return null;
      const date = typeof entry.date === 'number' && Number.isFinite(entry.date)
        ? entry.date
        : safeText(entry.date, 60);
      return { date, note };
    }).filter(Boolean) : [];

    return {
      id: safeText(raw.id, 100) || makeId(),
      title,
      due: isValidDateString(raw.due) ? raw.due : null,
      time: isValidTimeString(raw.time) ? raw.time : null,
      priority: PRIORITIES.includes(raw.priority) ? raw.priority : 'medium',
      store: 'THIPPASANDRA',
      notes: safeText(raw.notes, 2000),
      status,
      needsFollowUp: Boolean(raw.needsFollowUp),
      followUps,
      createdAt: Number.isFinite(raw.createdAt) ? raw.createdAt : Date.now(),
      completedAt: status === 'done' && Number.isFinite(raw.completedAt) ? raw.completedAt : null
    };
  }

  function showToast(message) {
    const toast = $('toast');
    clearTimeout(toastTimer);
    toast.textContent = message;
    toast.classList.add('visible');
    toastTimer = setTimeout(() => toast.classList.remove('visible'), 3600);
  }

  function setSyncStatus(message, isError = false) {
    const element = $('syncStatus');
    clearTimeout(syncTimer);
    element.textContent = message;
    element.classList.toggle('error', isError);
    syncTimer = setTimeout(() => {
      element.textContent = '';
      element.classList.remove('error');
    }, 6500);
  }

  function loadTasks() {
    try {
      const raw = localStorage.getItem(TASKS_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      tasks = Array.isArray(parsed) ? parsed.map(normalizeTask).filter(Boolean) : [];
    } catch (error) {
      tasks = [];
      showToast('Saved tasks could not be read. Export a fresh backup after adding tasks.');
    }
  }

  function saveTasks() {
    try {
      localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
      return true;
    } catch (error) {
      showToast('Browser storage is full or unavailable. Export a backup now.');
      return false;
    }
  }

  function loadChecklist() {
    try {
      const raw = localStorage.getItem(CHECKLIST_KEY);
      const parsed = raw ? JSON.parse(raw) : null;
      if (parsed && typeof parsed === 'object' && parsed.checked && typeof parsed.checked === 'object') {
        checklistState = { date: safeText(parsed.date, 10), checked: parsed.checked };
      } else {
        checklistState = { date: '', checked: {} };
      }
    } catch (error) {
      checklistState = { date: '', checked: {} };
    }
    if (checklistState.date !== todayStr()) {
      checklistState = { date: todayStr(), checked: {} };
      saveChecklist();
    }
  }

  function saveChecklist() {
    try {
      localStorage.setItem(CHECKLIST_KEY, JSON.stringify(checklistState));
      return true;
    } catch (error) {
      showToast('Checklist progress could not be saved in this browser.');
      return false;
    }
  }

  function fmtDateHuman(iso) {
    if (!isValidDateString(iso)) return '';
    const [year, month, day] = iso.split('-').map(Number);
    return new Date(year, month - 1, day).toLocaleDateString(undefined, {
      weekday: 'short', month: 'short', day: 'numeric', year: 'numeric'
    });
  }

  function followUpDateLabel(value) {
    if (typeof value === 'number' && Number.isFinite(value)) {
      return new Date(value).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
    }
    return value || 'Note';
  }

  function dueTimestamp(task) {
    if (!task.due) return Number.POSITIVE_INFINITY;
    return new Date(`${task.due}T${task.time || '23:59'}`).getTime();
  }

  function classify(task) {
    if (task.status === 'done') return 'done';
    if (!task.due) return task.needsFollowUp ? 'followup' : 'upcoming';
    const now = new Date();
    const dueDateTime = new Date(`${task.due}T${task.time || '23:59'}`);
    if (task.due < todayStr()) return 'overdue';
    if (task.due === todayStr()) {
      if (task.time && dueDateTime.getTime() < now.getTime()) return 'overdue';
      return 'today';
    }
    return task.needsFollowUp ? 'followup' : 'upcoming';
  }

  async function syncToSheet(action, payload, targetSheet, quiet = false) {
    if (!SHEET_URL) {
      if (!quiet) setSyncStatus('Saved in this browser; no sheet URL is configured.', true);
      return false;
    }
    try {
      const data = encodeURIComponent(JSON.stringify({ action, targetSheet, ...payload }));
      const url = `${SHEET_URL}?data=${data}&_t=${Date.now()}`;
      await fetch(url, { method: 'GET', mode: 'no-cors', cache: 'no-store', keepalive: true });
      if (!quiet) setSyncStatus('Sheet update sent — verify the row in Google Sheets.');
      return true;
    } catch (error) {
      if (!quiet) setSyncStatus('Saved in this browser; the sheet update could not be sent.', true);
      return false;
    }
  }

  function taskSheetPayload(task) {
    return {
      id: task.id,
      title: task.title,
      store: task.store,
      due: task.due || '',
      time: task.time || '',
      priority: task.priority,
      notes: task.notes,
      status: task.status
    };
  }

  function clearForm() {
    $('task-form').reset();
    $('in-priority').value = 'medium';
    $('in-title').removeAttribute('aria-invalid');
    $('formError').textContent = '';
  }

  function setFormMode() {
    const isEditing = Boolean(editingId);
    $('formHeading').textContent = isEditing ? 'Edit task' : 'Log a new task';
    $('btn-add').textContent = isEditing ? 'Save changes' : '+ Log task';
    $('btn-cancel-edit').hidden = !isEditing;
  }

  function cancelEdit() {
    editingId = null;
    clearForm();
    setFormMode();
  }

  function saveTaskFromForm() {
    const title = $('in-title').value.trim();
    const due = $('in-date').value || null;
    const time = $('in-time').value || null;
    const error = $('formError');

    error.textContent = '';
    $('in-title').removeAttribute('aria-invalid');

    if (!title) {
      error.textContent = 'Enter a task before saving.';
      $('in-title').setAttribute('aria-invalid', 'true');
      $('in-title').focus();
      return false;
    }
    if (time && !due) {
      error.textContent = 'Choose a due date when setting a due time.';
      $('in-date').focus();
      return false;
    }

    if (editingId) {
      const task = tasks.find((item) => item.id === editingId);
      if (!task) {
        cancelEdit();
        showToast('That task no longer exists.');
        return false;
      }
      Object.assign(task, {
        title,
        due,
        time,
        priority: $('in-priority').value,
        notes: $('in-notes').value.trim()
      });
      syncToSheet('update', taskSheetPayload(task), 'Tasks');
      editingId = null;
      showToast('Task updated.');
    } else {
      const task = {
        id: makeId(),
        title,
        due,
        time,
        priority: $('in-priority').value,
        store: 'THIPPASANDRA',
        notes: $('in-notes').value.trim(),
        status: 'pending',
        needsFollowUp: false,
        followUps: [],
        createdAt: Date.now(),
        completedAt: null
      };
      tasks.unshift(task);
      syncToSheet('add', taskSheetPayload(task), 'Tasks');
      showToast('Task logged.');
    }

    clearForm();
    setFormMode();
    saveTasks();
    render();
    return true;
  }

  function startEdit(id) {
    const task = tasks.find((item) => item.id === id);
    if (!task) return;
    editingId = id;
    $('in-title').value = task.title;
    $('in-date').value = task.due || '';
    $('in-time').value = task.time || '';
    $('in-priority').value = task.priority;
    $('in-notes').value = task.notes;
    setFormMode();
    $('formError').textContent = '';
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    $('task-form').scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
    $('in-title').focus({ preventScroll: true });
  }

  function toggleDone(id) {
    const task = tasks.find((item) => item.id === id);
    if (!task) return;
    const isDone = task.status !== 'done';
    task.status = isDone ? 'done' : 'pending';
    task.completedAt = isDone ? Date.now() : null;
    syncToSheet('update', { id, status: task.status, completedAt: task.completedAt || '' }, 'Tasks');
    saveTasks();
    render();
  }

  function deleteTask(id) {
    const task = tasks.find((item) => item.id === id);
    if (!task) return;
    if (!window.confirm(`Delete “${task.title}”? This cannot be undone.`)) return;
    tasks = tasks.filter((item) => item.id !== id);
    if (editingId === id) cancelEdit();
    syncToSheet('delete', { id }, 'Tasks');
    saveTasks();
    render();
    showToast('Task deleted.');
  }

  function toggleFollowUp(id) {
    const task = tasks.find((item) => item.id === id);
    if (!task) return;
    task.needsFollowUp = !task.needsFollowUp;
    syncToSheet('update', { id, needsFollowUp: task.needsFollowUp }, 'Tasks');
    syncToSheet('add', {
      ...taskSheetPayload(task),
      status: task.needsFollowUp ? 'followup' : 'removed',
      followUpDate: todayStr()
    }, 'FollowUps');
    saveTasks();
    render();
  }

  function addFollowUp(id) {
    const input = document.querySelector(`input[data-followup-input="${CSS.escape(id)}"]`);
    const task = tasks.find((item) => item.id === id);
    if (!input || !task) return;
    const note = input.value.trim();
    if (!note) {
      input.setAttribute('aria-invalid', 'true');
      input.focus();
      showToast('Write a follow-up note first.');
      return;
    }
    task.followUps.push({ date: Date.now(), note: note.slice(0, 1000) });
    syncToSheet('add', {
      ...taskSheetPayload(task),
      notes: note.slice(0, 1000),
      status: 'note',
      followUpDate: todayStr()
    }, 'FollowUps');
    saveTasks();
    render();
    showToast('Follow-up note added.');
  }

  function speakTask(id) {
    const task = tasks.find((item) => item.id === id);
    if (!task) return;
    if (!('speechSynthesis' in window) || typeof window.SpeechSynthesisUtterance !== 'function') {
      showToast('Read-aloud is not supported in this browser.');
      return;
    }
    const text = [
      task.title,
      task.store ? `at ${task.store}` : '',
      task.due ? `due on ${fmtDateHuman(task.due)}` : '',
      task.time ? `at ${task.time}` : '',
      task.notes
    ].filter(Boolean).join('. ');
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-IN';
    utterance.rate = 1;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  }

  function taskCard(task) {
    const category = classify(task);
    const stampMap = { overdue: 'Overdue', today: 'Due Today', done: 'Done', followup: 'Follow-up' };
    const stamp = stampMap[category]
      ? `<div class="stamp ${category}">${stampMap[category]}</div>`
      : '';
    const dueLabel = task.due
      ? `${fmtDateHuman(task.due)}${task.time ? ` · ${escapeHtml(task.time)}` : ''}`
      : 'No due date';
    const id = escapeHtml(task.id);
    const title = escapeHtml(task.title);
    const followUpsHtml = task.followUps.length ? `
      <div class="followups">
        ${task.followUps.map((entry) => `<div class="followup-entry"><b>${escapeHtml(followUpDateLabel(entry.date))}</b> — ${escapeHtml(entry.note)}</div>`).join('')}
      </div>` : '';
    const speechDisabled = !('speechSynthesis' in window) ? 'disabled title="Read-aloud is not supported in this browser"' : '';

    return `
      <article class="task ${task.status === 'done' ? 'done' : ''}" data-id="${id}">
        <input class="task-check" type="checkbox" data-action="toggle-done" data-id="${id}" ${task.status === 'done' ? 'checked' : ''} aria-label="Mark ${title} as ${task.status === 'done' ? 'pending' : 'done'}">
        <div class="task-body">
          <div class="task-head">
            <div class="task-title">${title}</div>
            ${stamp}
          </div>
          <div class="task-meta">
            <span>${dueLabel}</span>
            <span class="chip ${task.priority}">${task.priority}</span>
            ${task.store ? `<span class="chip store">${escapeHtml(task.store)}</span>` : ''}
          </div>
          ${task.notes ? `<div class="task-notes">${escapeHtml(task.notes)}</div>` : ''}
          ${followUpsHtml}
          <details class="followup-details" data-task-id="${id}">
            <summary>+ Add follow-up note</summary>
            <div class="fu-input-row">
              <input type="text" placeholder="What happened / next step..." maxlength="1000" data-followup-input="${id}" aria-label="Follow-up note for ${title}">
              <button type="button" data-action="add-followup" data-id="${id}">Add</button>
            </div>
          </details>
          <div class="task-actions">
            <button type="button" data-action="speak" data-id="${id}" ${speechDisabled}>Speak</button>
            <button type="button" class="fu-btn ${task.needsFollowUp ? 'active' : ''}" data-action="toggle-followup" data-id="${id}" aria-pressed="${task.needsFollowUp}">${task.needsFollowUp ? 'Following up' : 'Follow-up'}</button>
            <button type="button" data-action="edit" data-id="${id}">Edit</button>
            <button type="button" class="del" data-action="delete" data-id="${id}">Delete</button>
          </div>
        </div>
      </article>`;
  }

  function render() {
    const doneWasOpen = Boolean(document.querySelector('.done-block')?.open);
    const openFollowUps = new Set(Array.from(document.querySelectorAll('.followup-details[open]')).map((element) => element.dataset.taskId));
    const today = todayStr();
    currentDay = today;
    $('dateMeta').innerHTML = `<time datetime="${today}">${new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</time>`;

    const groups = { overdue: [], today: [], followup: [], upcoming: [], done: [] };
    tasks.forEach((task) => groups[classify(task)].push(task));
    Object.entries(groups).forEach(([name, group]) => {
      group.sort((a, b) => name === 'done'
        ? (b.completedAt || b.createdAt) - (a.completedAt || a.createdAt)
        : dueTimestamp(a) - dueTimestamp(b));
    });

    const pendingCount = tasks.filter((task) => task.status !== 'done').length;
    const doneToday = tasks.filter((task) => task.status === 'done' && task.completedAt && todayStr(new Date(task.completedAt)) === today).length;
    const followUpCount = tasks.filter((task) => task.needsFollowUp && task.status !== 'done').length;

    $('stats').innerHTML = `
      <div class="stat overdue"><div class="num">${groups.overdue.length}</div><div class="lbl">Overdue</div></div>
      <div class="stat today"><div class="num">${groups.today.length}</div><div class="lbl">Due Today</div></div>
      <div class="stat followup"><div class="num">${followUpCount}</div><div class="lbl">Follow-up</div></div>
      <div class="stat"><div class="num">${pendingCount}</div><div class="lbl">Pending</div></div>
      <div class="stat done"><div class="num">${doneToday}</div><div class="lbl">Done Today</div></div>`;

    let html = '';
    if (groups.followup.length) {
      html += '<h2 class="section-head followup">Follow-up Needed</h2>' + groups.followup.map(taskCard).join('');
    }
    if (groups.overdue.length) {
      html += '<h2 class="section-head overdue">Overdue</h2>' + groups.overdue.map(taskCard).join('');
    }
    if (groups.today.length) {
      html += '<h2 class="section-head today">Due Today</h2>' + groups.today.map(taskCard).join('');
    }
    if (groups.upcoming.length) {
      html += '<h2 class="section-head">Upcoming</h2>' + groups.upcoming.map(taskCard).join('');
    }
    if (!tasks.length) {
      html = '<div class="empty">Nothing logged yet. Add your first task above.</div>';
    }
    if (groups.done.length) {
      html += `<details class="done-block" ${doneWasOpen ? 'open' : ''}><summary>Done (${groups.done.length})</summary>${groups.done.map(taskCard).join('')}</details>`;
    }
    $('sections').innerHTML = html;

    document.querySelectorAll('.followup-details').forEach((element) => {
      if (openFollowUps.has(element.dataset.taskId)) element.open = true;
    });
  }

  function itemId(category, item) {
    return `${category}__${item}`.replace(/\s+/g, '_').toLowerCase();
  }

  function toggleChecklistItem(id) {
    checklistState.checked[id] = !checklistState.checked[id];
    saveChecklist();
    renderChecklist();
  }

  function resetChecklist() {
    if (!window.confirm("Reset every item on today's checklist?")) return;
    checklistState = { date: todayStr(), checked: {} };
    saveChecklist();
    renderChecklist();
    showToast("Today's checklist was reset.");
  }

  function renderChecklist() {
    let totalItems = 0;
    let totalChecked = 0;
    const groups = CHECKLIST_DATA.map((group) => {
      const rows = group.items.map((item) => {
        const id = itemId(group.cat, item);
        const checked = Boolean(checklistState.checked[id]);
        totalItems += 1;
        if (checked) totalChecked += 1;
        return `
          <div class="checklist-item ${checked ? 'checked' : ''}">
            <input type="checkbox" id="ci-${escapeHtml(id)}" data-checklist-id="${escapeHtml(id)}" ${checked ? 'checked' : ''}>
            <label for="ci-${escapeHtml(id)}">${escapeHtml(item)}</label>
          </div>`;
      }).join('');
      return `
        <section class="checklist-cat" style="--cat-color:${group.color}">
          <h3 class="checklist-cat-head"><span>${escapeHtml(group.cat)}</span></h3>
          <div class="checklist-items">${rows}</div>
        </section>`;
    }).join('');

    $('checklistBody').innerHTML = groups + `
      <div class="checklist-reset">
        <button type="button" class="checklist-reset-btn" id="btn-reset-checklist">Reset today's checklist</button>
      </div>`;
    $('checklistProgress').textContent = `${totalChecked} / ${totalItems} done today`;
  }

  function exportBackup() {
    const backup = {
      app: 'Daily Docket',
      version: 2,
      exportedAt: new Date().toISOString(),
      tasks,
      checklist: checklistState
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `daily-docket-backup-${todayStr()}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast('Backup downloaded.');
  }

  async function importBackup(file) {
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!data || !Array.isArray(data.tasks)) throw new Error('Invalid backup');
      const importedTasks = data.tasks.map(normalizeTask).filter(Boolean);
      if (data.tasks.length && !importedTasks.length) throw new Error('No valid tasks');
      if (!window.confirm(`Replace the tasks on this device with ${importedTasks.length} task(s) from this backup?`)) return;
      tasks = importedTasks;
      if (data.checklist && data.checklist.checked && typeof data.checklist.checked === 'object' && data.checklist.date === todayStr()) {
        checklistState = { date: todayStr(), checked: data.checklist.checked };
      } else {
        checklistState = { date: todayStr(), checked: {} };
      }
      cancelEdit();
      saveTasks();
      saveChecklist();
      render();
      renderChecklist();
      showToast('Backup imported. Sheet rows were not changed.');
    } catch (error) {
      showToast('That file is not a valid Daily Docket backup.');
    } finally {
      $('importFile').value = '';
    }
  }

  async function testConnection() {
    const button = $('btn-test');
    button.disabled = true;
    button.textContent = 'Sending test…';
    setSyncStatus('Sending test rows to both sheet tabs…');
    const id = `test-${Date.now()}`;
    const base = {
      id,
      title: 'DAILY DOCKET CONNECTION TEST',
      store: 'THIPPASANDRA',
      due: '',
      time: '',
      priority: 'medium',
      notes: 'Safe to delete this test row.',
      status: 'pending'
    };
    const results = await Promise.all([
      syncToSheet('add', base, 'Tasks', true),
      syncToSheet('add', { ...base, title: 'DAILY DOCKET FOLLOWUP TEST', status: 'followup', followUpDate: todayStr() }, 'FollowUps', true)
    ]);
    button.disabled = false;
    button.textContent = 'Test sheet connection';
    if (results.every(Boolean)) {
      setSyncStatus('Test rows sent — check both tabs in Google Sheets.');
    } else {
      setSyncStatus('One or both test rows could not be sent. Check your connection.', true);
    }
  }

  function setupVoice() {
    const micButton = $('btn-mic');
    const status = $('micStatus');
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      micButton.hidden = true;
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    let listening = false;

    recognition.onstart = () => {
      listening = true;
      micButton.classList.add('listening');
      micButton.setAttribute('aria-label', 'Stop listening');
      status.textContent = 'Listening… speak your task';
    };
    recognition.onresult = (event) => {
      let transcript = '';
      for (let index = 0; index < event.results.length; index += 1) {
        transcript += event.results[index][0].transcript;
      }
      $('in-title').value = transcript;
      if (event.results[event.results.length - 1].isFinal) {
        if (editingId) {
          status.textContent = 'Voice text added. Review and save your changes.';
        } else if (saveTaskFromForm()) {
          status.textContent = `Added: “${transcript.trim()}”`;
        }
      }
    };
    recognition.onerror = (event) => {
      if (event.error === 'not-allowed' || event.error === 'permission-denied') {
        status.textContent = 'Microphone permission denied.';
      } else if (event.error === 'no-speech') {
        status.textContent = "Didn't catch that — try again.";
      } else {
        status.textContent = `Voice input error: ${event.error}`;
      }
    };
    recognition.onend = () => {
      listening = false;
      micButton.classList.remove('listening');
      micButton.setAttribute('aria-label', 'Speak your task');
      setTimeout(() => { if (!listening) status.textContent = ''; }, 3500);
    };
    micButton.addEventListener('click', () => {
      if (listening) {
        recognition.stop();
      } else {
        status.textContent = '';
        try {
          recognition.start();
        } catch (error) {
          status.textContent = 'Voice input is already starting.';
        }
      }
    });
  }

  $('task-form').addEventListener('submit', (event) => {
    event.preventDefault();
    saveTaskFromForm();
  });
  $('btn-cancel-edit').addEventListener('click', cancelEdit);
  $('btn-export').addEventListener('click', exportBackup);
  $('btn-import').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', (event) => importBackup(event.target.files[0]));
  $('btn-print').addEventListener('click', () => window.print());
  $('btn-test').addEventListener('click', testConnection);

  $('sections').addEventListener('click', (event) => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    const { action, id } = button.dataset;
    if (action === 'speak') speakTask(id);
    if (action === 'toggle-followup') toggleFollowUp(id);
    if (action === 'edit') startEdit(id);
    if (action === 'delete') deleteTask(id);
    if (action === 'add-followup') addFollowUp(id);
  });
  $('sections').addEventListener('change', (event) => {
    const checkbox = event.target.closest('input[data-action="toggle-done"]');
    if (checkbox) toggleDone(checkbox.dataset.id);
  });
  $('sections').addEventListener('keydown', (event) => {
    const input = event.target.closest('input[data-followup-input]');
    if (input && event.key === 'Enter') {
      event.preventDefault();
      addFollowUp(input.dataset.followupInput);
    }
  });
  $('checklistBody').addEventListener('change', (event) => {
    const checkbox = event.target.closest('input[data-checklist-id]');
    if (checkbox) toggleChecklistItem(checkbox.dataset.checklistId);
  });
  $('checklistBody').addEventListener('click', (event) => {
    if (event.target.closest('#btn-reset-checklist')) resetChecklist();
  });

  loadTasks();
  loadChecklist();
  render();
  renderChecklist();
  setupVoice();

  setInterval(() => {
    if (todayStr() !== currentDay) {
      loadChecklist();
      render();
      renderChecklist();
    }
  }, 60000);

  if ('serviceWorker' in navigator && /^https?:$/.test(window.location.protocol)) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js').catch(() => {
        showToast('Offline installation is unavailable here; browser storage and backups still work.');
      });
    });
  }
})();
